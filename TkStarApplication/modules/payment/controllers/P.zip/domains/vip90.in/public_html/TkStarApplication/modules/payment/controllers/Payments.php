<?php
class Payments extends Public_Controller {
    public $validation_rules = array('credit' => array(array('field' => 'amount', 'rules' => 'numeric|trim|required|htmlspecialchars', 'label' => 'مبلغ شارژ')));
    public function __construct () {
        parent::__construct();
        $this->load->eloquent('settings/Setting');
		$this->load->sentinel();
		$this->load->helper('cookie');
		if(!$this->sentinel->check()){
			if(isset($_COOKIE['auto_login']) AND !empty($_COOKIE['auto_login'])){
				$auto_login = $_COOKIE['auto_login'];
				$auto_login = explode('{{TkStar_Cookie}}', $auto_login);
				if(isset($auto_login[0]) AND isset($auto_login[1]) AND !empty($auto_login[0]) AND !empty($auto_login[1])){
					$credentials = array('email' => $auto_login[0], 'password' => $auto_login[1]);
					$auth_user = $this->sentinel->authenticate($credentials);
					if($auth_user){
						header('Location: ' . base_url($_SERVER['REQUEST_URI']));exit();
					}
				}
			}
		}
    }
    public function credit () {
        $this->checkAuth(true);
        $this->load->library('zahedipal');
        $amount = $this->input->post('amount');
        $type = $this->input->post('type');
        if ( $this->formValidate(FALSE) ) {
            if($type == 'pm'){
                $this->load->eloquent('Transaction');
                $cash = $this->__getUserCash();
                Transaction::create(array('trans_id' => '1', 'price' => $amount, 'invoice_type' => 1, 'cash' => $cash + $amount, 'user_id' => $this->user->id, 'description' => 'افزایش موجودی حساب'));
                echo('<form name=\'myForm\' action=\'https://perfectmoney.is/api/step1.asp\' method=\'POST\'><input type=\'hidden\' name=\'PAYEE_ACCOUNT\' value=\'U17262536\'><input type=\'hidden\' name=\'PAYEE_NAME\' value=\'Vip90 Payment\'><input type=\'hidden\' name=\'PAYMENT_ID\' value=\'' . time() . '\'><input type=\'hidden\' name=\'PAYMENT_AMOUNT\' value=\'' . round($amount / 9000, 2) . '\'><input type=\'hidden\' name=\'PAYMENT_UNITS\' value=\'USD\'><input type=\'hidden\' name=\'STATUS_URL\' value=\'' . site_url('payment/credit') . '\'><input type=\'hidden\' name=\'PAYMENT_URL\' value=\'' . site_url('payment/credit') . '\'><input type=\'hidden\' name=\'PAYMENT_URL_METHOD\' value=\'POST\'><input type=\'hidden\' name=\'NOPAYMENT_URL\' value=\'' . site_url('payment/credit') . '\'><input type=\'hidden\' name=\'NOPAYMENT_URL_METHOD\' value=\'POST\'><input type=\'hidden\' name=\'SUGGESTED_MEMO\' value=\'\'><input type=\'hidden\' name=\'BAGGAGE_FIELDS\' value=\'IDENT\'><br></form><script type=\'text/javascript\'>window.onload = function(){document.forms[\'myForm\'].submit();}</script>');exit();
            }else{
                $data = json_encode(array('pin' => $this->api_token, 'price' => $amount, 'order_id' => 1, 'callback' => 'http://persepolisbookshop.com/verfiy.php', 'ip'=> $_SERVER['REMOTE_ADDR'], 'callback_type' => 2));
                $res = $this->zahedipal->zpCurl($data);
                $res = json_decode($res, false);
                $transID = $res->form_details->fields->Token;
                $_SESSION['au'] = $res->au;
                $_SESSION['amount'] = $amount;
                $_SESSION['transID'] = $transID;
                $this->load->eloquent('Transaction');
                $cash = $this->__getUserCash();
                Transaction::create([
                    'trans_id' => $res->au,
                    'savano' => $transID,
                    'price' => $amount ,
                    'invoice_type' => 1 ,
                    'cash' => $cash + $amount ,
                    'user_id' => $this->user->id ,
                    'description' => 'Ø´Ø§Ø±Ú˜ Ø­Ø³Ø§Ø¨ Ú©Ø§Ø±Ø¨Ø±ÛŒ' ,
                ]);
                header("Location: https://pec.shaparak.ir/NewIPG/?Token=".$transID);exit();
            }
        } else {
            $this->smart->view('credit');
        }
    }
    public function transactions(){
        $this->checkAuth(true);
        $this->load->eloquent('transaction');
		$this->CI = get_instance();
		$this->CI->load->database();
		$all_transactions = array();
		$query_baccarat_transactions = $this->CI->db->conn_id->query("SELECT * FROM `baccarats_table` WHERE `user` = '" . $this->user->id . "'")->fetch_all(MYSQLI_ASSOC);
		$query_blackjack_transactions = $this->CI->db->conn_id->query("SELECT * FROM `blackjacks_table` WHERE `user` = '" . $this->user->id . "'")->fetch_all(MYSQLI_ASSOC);
		$query_plinko_transactions = $this->CI->db->conn_id->query("SELECT * FROM `plinkoes_table` WHERE `user` = '" . $this->user->id . "'")->fetch_all(MYSQLI_ASSOC);
		$query_roulette_transactions = $this->CI->db->conn_id->query("SELECT * FROM `roulettes_table` WHERE `user` = '" . $this->user->id . "'")->fetch_all(MYSQLI_ASSOC);
		$query_crash_transactions = $this->CI->db->conn_id->query("SELECT * FROM `crash_table` WHERE `users` != '{}' AND `users` != '[]' AND `play` = '0'")->fetch_all(MYSQLI_ASSOC);
        $transactions = Transaction::where('user_id' , $this->user->id)->orderBy('id' , 'desc')->get();
		foreach($query_baccarat_transactions as $transaction){
			$transaction = (object)$transaction;
			$all_transactions[$transaction->time] = array('trans_id' => 1000000 . $transaction->time, 'created_at' => $transaction->time, 'description' => 'بازی باکارات کازینو', 'price' => $transaction->price, 'status' => '1');
		}
		foreach($query_blackjack_transactions as $transaction){
			$transaction = (object)$transaction;
			$all_transactions[$transaction->time] = array('trans_id' => 1000000 . $transaction->time, 'created_at' => $transaction->time, 'description' => 'بازی بلک جک (21) کازینو', 'price' => $transaction->price, 'status' => '1');
		}
		foreach($query_plinko_transactions as $transaction){
			$transaction = (object)$transaction;
			$all_transactions[$transaction->time] = array('trans_id' => 1000000 . $transaction->time, 'created_at' => $transaction->time, 'description' => 'بازی توپ و سبد کازینو', 'price' => $transaction->price, 'status' => '1');
		}
		foreach($query_roulette_transactions as $transaction){
			$transaction = (object)$transaction;
			$all_transactions[$transaction->time] = array('trans_id' => 1000000 . $transaction->time, 'created_at' => $transaction->time, 'description' => 'بازی رویال رولت کازینو', 'price' => $transaction->price, 'status' => '1');
		}
		foreach($query_crash_transactions as $crash){
			$crash = (object)$crash;
			$users = $crash->users;
			$users = json_decode($users, true);
			if(count($users) <= 0){
				continue;
			}else{
				$users = (object)$users;
				foreach($users as $user_id => $user_odd){
					if($user_id == $this->user->id){
						$user_odd = (object)$user_odd;
						$price = ($user_odd->win == '1' OR $user_odd->win == 1) ? $user_odd->price : $user_odd->price - ($user_odd->price * 2);
						$all_transactions[$crash->finish_time] = array('trans_id' => 1000000 . $crash->finish_time, 'created_at' => $crash->finish_time, 'description' => 'بازی انفجار کازینو', 'price' => $price, 'status' => '1');
					}else{
						continue;
					}
				}
			}
		}
		foreach($transactions as $transaction){
			$transaction = (object)$transaction;
			$all_transactions[strtotime($transaction->created_at)] = array('trans_id' => $transaction->trans_id, 'created_at' => strtotime($transaction->created_at), 'description' => $transaction->description, 'price' => $transaction->price, 'status' => $transaction->status);
		}
		krsort($all_transactions);
        $this->smart->assign(array('transactions' => $all_transactions, 'title' => 'سابقه تراکنش ها', 'cash' => $this->__getUserCash(), 'transaction_states' => 1, '_GET' => $_GET));
        $this->smart->view('transactions');
    }

}
